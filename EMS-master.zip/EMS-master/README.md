# EMS
Employee Management System POC with microservices and google oauth.
