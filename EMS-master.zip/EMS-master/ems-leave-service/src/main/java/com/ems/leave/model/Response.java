package com.ems.leave.model;

/**
 * 
 * @author yogesh.patil
 *
 */
public class Response {

	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
